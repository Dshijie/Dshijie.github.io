# GitHub Pages Blog (Jekyll)

This is a minimal multi-file Jekyll template for a blog + résumé page on GitHub Pages.

## Local preview
1) Install Ruby + Bundler
2) Run:
   bundle install
   bundle exec jekyll serve
3) Open:
   http://localhost:4000

## Add a post
Create a file in `_posts/`:
YYYY-MM-DD-your-title.md

Front matter skeleton:
---
layout: post
title: ""
date: YYYY-MM-DD
categories: []
tags: []
---

(Write markdown content below.)
